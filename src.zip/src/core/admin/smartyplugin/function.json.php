<?php
function tpl_function_json($params, &$smarty){

    return json_encode($params['from']);
}

?>
