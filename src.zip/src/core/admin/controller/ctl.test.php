<?php
class ctl_test extends adminPage{
    var $old_path ='E:/htdocs/shopex_trunk/vip/485app';
    function index(){
        set_time_limit(0);
        $goodsObj = &$this->system->loadModel('goods/products');
        $imgObj = &$this->system->loadModel('goods/gimage');
        $list = $goodsObj->getList('goods_id,thumbnail_pic,small_pic,big_pic,image_file',array(),0,600);
        //echo "<pre>";print_r($list);exit();
        //$list[]=array('goods_id'=>4023);
        foreach($list as $g_k => $g_v){            
            $thumbnail_pic = substr($g_v['thumbnail_pic'],0,strpos($g_v['thumbnail_pic'],"|"));
            $small_pic = substr($g_v['small_pic'],0,strpos($g_v['small_pic'],"|"));
            $big_pic = substr($g_v['big_pic'],0,strpos($g_v['big_pic'],"|"));
            $image_file = substr($g_v['image_file'],0,strpos($g_v['image_file'],"|"));
            
            error_log("---------------".$g_v['goods_id']."--------------\n",3,"e:\abc.txt");
            error_log("thumbnail_pic:".BASE_DIR."/".$thumbnail_pic."\n",3,"e:\abc.txt");
            error_log("small_pic:".BASE_DIR."/".$small_pic."\n",3,"e:\abc.txt");
            error_log("big_pic:".BASE_DIR."/".$big_pic."\n",3,"e:\abc.txt");
            error_log("image_file:".BASE_DIR."/".$image_file."\n",3,"e:\abc.txt");
            
            if(!is_dir($dir = dirname(BASE_DIR."/".$thumbnail_pic))){
                mkdir_p($dir,0777);                    
            }
            copy($this->old_path."/".$thumbnail_pic,BASE_DIR."/".$thumbnail_pic);
            
            if(!is_dir($dir = dirname(BASE_DIR."/".$small_pic))){
                mkdir_p($dir,0777);                    
            }
            copy($this->old_path."/".$small_pic,BASE_DIR."/".$small_pic);
            
            if(!is_dir($dir = dirname(BASE_DIR."/".$big_pic))){
                mkdir_p($dir,0777);                    
            }
            copy($this->old_path."/".$big_pic,BASE_DIR."/".$big_pic);
            
            if(!is_dir($dir = dirname(BASE_DIR."/".$image_file))){
                mkdir_p($dir,0777);                    
            }                
            copy($this->old_path."/".$image_file,BASE_DIR."/".$image_file);
            
            /*
            $imglist = $imgObj->get_by_goods_id($g_v['goods_id']);            
            foreach($imglist as $i_k => $i_v){
                $source = HOME_DIR."/".$i_v['source'];
                $small = substr($i_v['small'],0,strpos($i_v['small'],"|"));
                $big = substr($i_v['big'],0,strpos($i_v['big'],"|"));
                $thumbnail = substr($i_v['thumbnail'],0,strpos($i_v['thumbnail'],"|"));
                
                error_log("source:".$source."\n",3,"e:\abc.txt");
                error_log("small:".BASE_DIR."/".$small."\n",3,"e:\abc.txt");
                error_log("big:".BASE_DIR."/".$big."\n",3,"e:\abc.txt");
                error_log("thumbnail:".BASE_DIR."/".$thumbnail."\n",3,"e:\abc.txt");
                
                if(!is_dir($dir = dirname($source))){
                    mkdir_p($dir,0777);                    
                }
                copy($this->old_path."/".$source,HOME_DIR."/".$source);
                
                if(!is_dir($dir = dirname(BASE_DIR."/".$small))){
                    mkdir_p($dir,0777);                    
                }
                copy($this->old_path."/".$small,BASE_DIR."/".$small);
                
                if(!is_dir($dir = dirname(BASE_DIR."/".$big))){
                    mkdir_p($dir,0777);                    
                }
                copy($this->old_path."/".$big,BASE_DIR."/".$big);
                
                if(!is_dir($dir = dirname(BASE_DIR."/".$thumbnail))){
                    mkdir_p($dir,0777);                    
                }                
                copy($this->old_path."/".$thumbnail,BASE_DIR."/".$thumbnail);
            }
            */
        }
    }
}

?>
